******************************************************************************
*                                                                            *
*                   Welcome to IRISCC Project                                *
*                                                                            *
******************************************************************************



IRISCC = Freeiris2 + AsterCC

Freeiris2和AsterCC是中国2个知名的通信开源项目，一个是IPPBX，一个是CallCenter,
一直以来，这两个著名的系统却从未联合在一起，但现在不同的，IRISCC让强强联合，优秀
的IPPBX加上优秀的CallCenter满足你们众多的梦想

Docs
----

安装方法请看 INSTALL.html

Freeiris2的开发文档可以查看doc目录（已经没有更新）.

IRISCC:
Xu Hao <loveme1314@gmail.com>     Copyright © 2013-2014

Freeiris2：
sun bing <hoowa.sun@freeiris.org> Copyright © 2005-2012

Astercc 
www.astercc.org