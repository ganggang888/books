<?
//En for mangaer
$add_account = "Registo agregado";
$update_rec = "Un registro ha sido actualizado";
$rec_cannot_update = "El registro no pudo ser actualizado";
$rec_cannot_insert = "El registro no pudo ser insertado";
$delete_rec = "Registro eliminado";
$rec_cannot_delete = "El Registro no pudo ser eliminado";
$username = "Nombre de Usuario ";
$password = "Contraseña ";
$extension = "Extension ";
$extensions = "Extensiones";
$extensions_note = "Use coma entre extensiones ";
$continue = "Continuar";
$obligatory_fields = "* Campos Obligatorios";
$adding_account = "Agregando Cuenta";
$edit_account = "Editando Cuenta";
$usertype = "Tipo de Usuario";
$usertype_note = "Admin Soport,Caseta";
$channel	= "Chanal";	// added 2007/10/30 by solo
$account_detail		= "Detalle de Cuenta";	// added 2007/10/30 by solo
$account_code		= "Codigo de Cuenta";	// added 2007/11/12 by solo
$username_repeat = "Nombre de Usuario Repetido";
?>