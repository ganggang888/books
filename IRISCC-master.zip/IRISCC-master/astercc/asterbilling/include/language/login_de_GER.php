<?
$title="Benutzer Login ";
$username="Benutzer Name ";
$password="Passwort ";
$submit="Weiter";
$please_waiting = "login, Bitte warten";
$username_cannot_be_blank = "Benutzerfeld bitte ausfüllen";
$password_cannot_be_blank = "Passworfeld bitte ausfüllen";
$login_success = "Benutzer login erfolgreich";
$login_failed = "Login fehlgeschlagen, Überprüfen Sie Ihren Benutzernamen/Passwort";
$ami_connect_failed = "AMI verbinden fehlgeschlagen, eine Funkion konnte nicht ausgeführt werden, bitte Überprüfen Sie Ihre Config Datei";
$extension_not_online = "Die Erweiterung ist offline, Bitte Überprüfen Sie Ihre Software/Hardware";
$server_connection_test		= "Server Verbindungstest: ";
$pass				= "Bestanden";
$device_status			= "Software/Hardware status";
$continue			= "Weiter";
$no_pass			= "Zugang fehlgeschlagen, bitte Überprüfen Sie die Konfiguration";
$invalid_string		= "Unzuläsiger Eintrag, Es sind nur Ziffern/buchstaben zulässig";
?>
