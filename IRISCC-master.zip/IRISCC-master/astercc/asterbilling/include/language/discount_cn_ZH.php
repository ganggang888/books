<?
$discount	= "折扣";
$amount = "总计额度";
$create_time = "创建时间";
$like = "包含";
$edit_discount = "修改折扣";
$add_discount = "添加折扣";
$continue = "继续";
$discount_must_be_ge_0_and_le_1 = "折扣数必须大于0小于1";
$amount_duplicate = "总计额度重复";
$obligatory_fields = "必填字段";
?>
