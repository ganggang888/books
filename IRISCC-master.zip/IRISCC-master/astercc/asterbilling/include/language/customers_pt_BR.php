<?
$pin	= "PIN";
$first_name = "Nome";
$last_name = "Sobrenome";
$amount = "Quantidade";
$create_time = "Tempo de Criação";
$like = "Como";
$discount = "Desconto";
$edit_customer = "Editar Cliente";
$add_customer = "Adicionar Cliente";
$dynamic = "Dinâmico";
$static = "Estático";
$continue = "Continuar";
$pin_field_cant_be_null = "Campo PIN não pode ser vazio";
$pin_duplicate = "PIN Duplicado";
$discount_must_be_ge_0_and_le_1 = "Desconto deve ser entre 0 e 1";
$obligatory_fields = "Campos Obrigatórios";
?>
