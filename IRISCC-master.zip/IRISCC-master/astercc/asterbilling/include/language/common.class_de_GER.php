<?
$username	= "Username";
$user_type = "Usertyp";
$account = "ACCOUNT";
$account_group = "CALLSHOP";
$reseller_group = "RESELLER";
$report = "BERICHT";
$statistic = "STATISTIK";
$rate_to_customer = "TARIFE ENDKUNDEN";
$rate_to_callshop = "TARIFE CALLSHOPS";
$rate_to_reseller = "TARIFE RESELLER";
$clid = "KABINEN";
$import = "IMPORT";
$cdr = "CDR";
$credit_history = "ZAHLUNGEN";
$logout = "LOGOUT";
$are_u_sure_to_exit = "Wollen Sie ausloggen ";
?>
