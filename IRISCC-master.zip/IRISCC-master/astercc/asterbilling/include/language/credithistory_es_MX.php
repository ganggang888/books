<?
$like = "Como ";
$modifytime = "Modificar tiempo";
$clid = "Cabina";
$srccredit = "Credito origen";
$modifystatus = "Modificar Status";
$modifyamount = "Modificar Cantidad";
$resellername = "Distribuidor";
$group  = "Caseta";
$modifyby = "Modificar por";
?>
