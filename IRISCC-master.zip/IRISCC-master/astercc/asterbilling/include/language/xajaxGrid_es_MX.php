<?
$edit = "Editar";
$detail = "Detalle";
$delete = "Eliminar";
$select_field ="- Seleccionar campo - ";
$select_type ="- Seleccionar tipo -";
$select_option="- Seleccionar Opcion -";
$searchdelete_confirm="Esta seguro de eliminar estos registros?\\nSi no selecciono el contenido de la busqueda , esto borrara todos los registros!";
$add_record = "Agregar";
$table = "Tabla";
$search = "Busqueda";
$by = "Por";
$continue = "Continuar";
$first = "<< Primero";
$previous = "< Anterior";
$total = "Total";
$next = "Proximo >";
$last = "Ultimo >>";
$show_all = "Mostrar Todo";
$delete_confirm	= "Esta seguro de querer eliminar este registro ?";
$add_search = "Agregar objeto de busqueda";
$export = "Exportar";
?>
