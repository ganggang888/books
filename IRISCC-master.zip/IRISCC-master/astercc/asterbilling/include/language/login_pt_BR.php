<?
$user_title="Nome de Usuário ";
$manager_title="Administração ";

$username="Nome de Usuário ";
$password="Senha ";
$submit="Entrar ";
$please_waiting = 'Acessando, Por favor espere';
$username_cannot_be_blank = "Nome de usuário não pode estar em branco ";
$password_cannot_be_blank = "Senha não pode estar em branco ";
$login_success = "Acessado com sucesso";
$login_failed = "Acesso Falhou, Por favor cheque seu usuário e senha";
$ami_connect_failed = "Coinexão a AMI fahou, Alguma função podería não funcionar, por favor revise seu arquivo de configuração";
$extension_not_online = "Extensão esta desconectada, por favor revise seu dispositivo ou softphone";
$server_connection_test		= "Teste de conexão ao servidor: ";
$pass				= "Passou";
$device_status			= "Estado do dispositivo Voip";
$continue			= "Continuar";
$no_pass			= "Não passou, Por favor revise seu arquivo de configuração";
$invalid_string		= "Entrada Invalida, Somente números e letras são permitidos";
?>
