<?
$amount = "Today Amount";
$cost = "Today Cost";
$limit = "Limit";
$current_credit = "Current Cost";
?>