<?
$like = "包含";
$src = "主叫";
$dst = "被叫";
$srcname = "主叫名";
$starttime = "开始时间";
$answertime = "应答时间";
$groupname = "组";
$resellername = "代理商";
?>