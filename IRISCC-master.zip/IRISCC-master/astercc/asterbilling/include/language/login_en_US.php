<?
$user_title="User Login ";
$manager_title="Manager Login ";
$username="Username ";
$password="Password ";
$submit="Submit ";
$please_waiting = 'login, please wait';
$username_cannot_be_blank = "Username field can not be blank";
$password_cannot_be_blank = "Password field can not be blank";
$login_success = "user login success";
$login_failed = "Login failed, please check your username/password";
$ami_connect_failed = "AMI connect failed, some function could not work, please check your config file";
$extension_not_online = "extension is off line, please check your device";
$server_connection_test		= "Server connection test: ";
$pass				= "passed";
$device_status			= "Device status";
$continue			= "Contunue";
$no_pass			= "no pass, please check your configuration file";
$invalid_string		= "Invalid input, only digits or letters allowed";
$page_style = "Page Style";
$classic = "Classic";
$simple = "Simple";
$language = "Language";
$please_install_php_pear = "Please install php-pear";
?>
