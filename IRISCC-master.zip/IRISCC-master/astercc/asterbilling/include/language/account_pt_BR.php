<?
//En for mangaer
$add_account = "Registro efetuado com sucesso";
$update_rec = "Um registro foi atualizado";
$rec_cannot_update = "O registro não pode ser atualizado";
$rec_cannot_insert = "O Registro não pode ser inserido";
$delete_rec = "Registro eliminado";
$rec_cannot_delete = "O registro não pode ser eliminado";
$username = "Nome de Usuário ";
$password = "Senha ";
$extension = "Extensão ";
$extensions = "Extensões";
$extensions_note = "Use virgula entre extensões ";
$continue = "Continuar";
$obligatory_fields = "* Campos Obrigatórios";
$adding_account = "Criando Conta";
$edit_account = "Editando Conta";
$usertype = "Tipo de Usuário";
$usertype_note = "Admin Suporte,Callshop";
$channel	= "Chanal";	// added 2007/10/30 by solo
$account_detail		= "Detalhe da Conta";	// added 2007/10/30 by solo
$account_code		= "Código da Conta";	// added 2007/11/12 by solo
$username_repeat = "Nome de Usuário Repetido";
?>