<?
$pin	= "PIN";
$first_name = "Primer Nombre";
$last_name = "Ultimo Nombre";
$amount = "Cantidad";
$create_time = "Tiempo de Creacion";
$like = "Como";
$discount = "Descuento";
$edit_customer = "Editar Cliente";
$add_customer = "Agregar Cliente";
$dynamic = "Dinamico";
$static = "Estatico";
$continue = "Continuar";
$pin_field_cant_be_null = "Campo PIN no puede ser vacio";
$pin_duplicate = "PIN Duplicado";
$discount_must_be_ge_0_and_le_1 = "Decuento debe estar entre 0 y 1";
$obligatory_fields = "Campos Obligatorios";
?>
