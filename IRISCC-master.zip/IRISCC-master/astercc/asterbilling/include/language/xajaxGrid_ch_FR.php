<?
$edit = "Editer";
$detail = "Detail";
$delete = "Supprimer";
$select_field ="- Selectionnez un champ - ";
$select_type ="- Selectionnez un type -";
$add_record = "Ajouter";
$table = "Table";
$search = "Chercher";
$by = "By";
$continue = "Continuer";
$first = "<< Premier";
$previous = "< Precedent";
$total = "Total";
$next = "Suivant >";
$last = "Dernier >>";
$show_all = "Afficher tout";
$delete_confirm	= "Etes vous s�r de vouloir supprimer cet enregistrement?";
$add_search = "Add Search Object";
$export = "Exporter";
?>
