<?
$edit = "Editar";
$detail = "Detalhe";
$delete = "Eliminar";
$select_field ="- Selecionar campo - ";
$select_type ="- Selecionar tipo -";
$select_option="- Selecionar Opção -";
$searchdelete_confirm="Esta certo de eliminar estes registros?\\você não selecionou o conteúdo da busca , isto apagará todos os registros!";
$add_record = "Adicionar";
$table = "Tabela";
$search = "Busca";
$by = "Por";
$continue = "Continuar";
$first = "<< Primero";
$previous = "< Anterior";
$total = "Total";
$next = "Próximo >";
$last = "Último >>";
$show_all = "Mostrar Todos";
$delete_confirm	= "Está certo de querer eliminar este registro ?";
$add_search = "Adicionar objeto de busca";
$export = "Exportar";
?>
