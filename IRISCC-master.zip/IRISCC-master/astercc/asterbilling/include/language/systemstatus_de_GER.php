<?
$rate = "Tarif";
$report = "Bericht";
 
$last_refresh_time = "Letzte Aktualisierung";
$search_rate = "Suche Tarif";
 
$phone = "Nummer";
$sec = "Dauer";
$price = "Kosten";
$start_at = "Start";
 
$hangup = "Stop";
$clear = "Bezahlt";
$cdr = "CDR";
$receipt = "Rechnung";
$available_balance="Aktuelles Guthaben";
?>