<?
$edit = "ändern";
$detail = "Detail";
$delete = "löschen";
$select_field ="- Feld  auswählen - ";
$add_record = "Eintrag hinzufuegen";
$table = "Schreibtisch";
$search = "Suche";
$by = "Nach";
$continue = "Weiter";
$first = "<< Erste Seite";
$previous = "< Vorherige Seite";
$total = "Alles";
$next = "nächste  >";
$last = "Letzete Seite >>";
$show_all = "Zeige Alle";
$delete_confirm	= "Sind Sie sicher, daß Sie den Eintrag löschen wollen?";
$add_search = "Add Search Object";
$export = "export";
$display_all = "AP";
?>