<?
$username	= "Nome de usuário";
$user_type = "Tipo de usuário";
$account = "CONTA";
$account_group = "CALLSHOP";
$reseller_group = "DISTRIBUIDOR";
$report = "RELATÒRIO";
$statistic = "ESTATÌSTICAS";
$rate_to_customer = "TARIFA CLIENTE";
$rate_to_callshop = "TARIFA CALLSHOP";
$rate_to_reseller = "TARIFA DISTRIBUIDOR";
$clid = "CABINE";
$import = "IMPORTAR";
$cdr = "CDR";
$credit_history = "REGISTRO CRÉDITO";
$logout = "SAIR";
$are_u_sure_to_exit = "Está certo de sair ";
?>
