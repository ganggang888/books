<?
$calldate = "Data da Ligação";
$src = "Origem";
$dst = "N. Discado";
$duration = "Duração";
$billsec = "Segundos faturados";
$disposition = "Estado";
$credit = "Em Crédito";
$destination = "Destino";
$memo = "Nota";
$like = "Como";

?>
