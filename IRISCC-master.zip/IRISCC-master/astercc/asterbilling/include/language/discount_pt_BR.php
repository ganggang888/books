<?
$discount	= "Desconto";
$amount = "Quantidade";
$create_time = "Tempo de Criação";
$like = "Como";
$edit_discount = "Editar Conta";
$add_discount = "Adicionar Desconto";
$continue = "Continuar";
$discount_must_be_ge_0_and_le_1 = "Desconto deve ser entre 1 e 0";
$amount_duplicate = "Quantidade Duplicada";
$obligatory_fields = "Campos Obrigatórios";
?>
