<?
//En for mangaer
$add_account = "Un nouveau compte a ete cree";
$update_rec = "Le compte a ete mis � jour";
$rec_cannot_update = "Le compte n'a pas pu �tre mis � jour";
$rec_cannot_insert = "Le compte n'a pas pu �tre insere";
$delete_rec = "Compte supprime";
$rec_cannot_delete = "Le compte n'a pas pu �tre supprime";
$username = "Nom d'utilisateur ";
$password = "Mot de passe ";
$extension = "Extension ";
$extensions = "Extensions";
$extensions_note = "Utilisez une virgule entre les extensions ";
$continue = "Continuer";
$obligatory_fields = "* Champs obligatoires";
$adding_account = "Ajout d'un compte";
$edit_account = "Editez un compte";
$usertype = "Type d'utilisateur";
$usertype_note = "support admin,callshop";
$channel	= "Channel";	// added 2007/10/30 by solo
$account_detail		= "Detail de votre compte";	// added 2007/10/30 by solo
$account_code		= "Account Code";	// added 2007/11/12 by solo
$username_repeat = "user name repeat";

?>