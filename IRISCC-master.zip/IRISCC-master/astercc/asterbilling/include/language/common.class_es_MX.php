<?
$username	= "Nombre de usuario";
$user_type = "Tipo de usuario";
$account = "CUENTA";
$account_group = "CASETA";
$reseller_group = "DISTRIBUIDOR";
$report = "REPORTE";
$statistic = "ESTADISTICAS";
$rate_to_customer = "TARIFA CLIENTE";
$rate_to_callshop = "TARIFA CASETA";
$rate_to_reseller = "TARIFA DISTRIBUIDOR";
$clid = "CABINA";
$import = "IMPORTAR";
$cdr = "CDR";
$credit_history = "REGISTRO CREDITO";
$logout = "SALIR";
$are_u_sure_to_exit = "Esta seguro de salir de la sesion ";
?>
