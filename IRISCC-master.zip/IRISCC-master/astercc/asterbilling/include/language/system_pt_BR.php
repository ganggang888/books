<?
//En for mangaer
$reload_info = "- Resetar Asterisk (todas as chamadas ativas cairão)";
$restart_info = "- Asterisk será forçado a reiniciar (todas as chamadas ativas cairão)";
$reboot_info = "- Reiniciar seu asterCC Box (todas as chamadas ativas cairão)";
$shutdown_info = "- The asterCC Box irá iniciar o desligamento (todas as chamadas ativas cairão)";
?>