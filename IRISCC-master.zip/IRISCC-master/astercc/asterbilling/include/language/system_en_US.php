<?
//En for mangaer
$reload_info = "- Reset Asterisk (all active calls will not be dropped)";
$restart_info = "- Asterisk will be forced to restart (all active calls will be dropped)";
$reboot_info = "- Reboots your asterCC Box (all active calls will be dropped)";
$shutdown_info = "- The asterCC Box will begin a power down process (all active calls will be lost)";
?>