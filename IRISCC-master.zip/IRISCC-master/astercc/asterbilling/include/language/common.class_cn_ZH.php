<?
$username	= "用户名";
$user_type = "用户类型";
$account = "用户管理";
$account_group = "分组管理";
$reseller_group = "代理商管理";
$report = "报告";
$statistic = "统计";
$rate_to_customer = "用户费率";
$rate_to_callshop = "分组费率";
$rate_to_reseller = "代理商费率";
$clid = "分机";
$import = "导入";
$cdr = "通话记录";
$credit_history = "充值记录";
$logout = "退出";
$are_u_sure_to_exit = "确定要退出么";
$customer = "客户";
$discount = "折扣";
$profile = "用户信息";
$system = "系统";
$systemstatus = "操作界面";
$account_log = "登录日志";
$curcdr = "实时通话记录";
$delete_rate = "删除费率";
?>
