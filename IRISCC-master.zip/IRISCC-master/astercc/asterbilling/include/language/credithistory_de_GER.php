<?
$like = "Wie";
$modifytime = "Änderungsdatum";
$clid = "Kabine";
$srccredit = "Ursprünglicher Kredit";
$modifystatus = "Art";
$modifyamount = "Betrag";
$resellername = "Reseller";
$group  = "Callshop";
$modifyby = "geändert von";
?>
