<?
$edit = "Edit";
$detail = "Detail";
$delete = "Delete";
$select_field ="- Select field - ";
$select_type ="- Select type -";
$select_option="- Select option -";
$searchdelete_confirm="Are you sure to delete these records?\\nIf you did not select the search content and search filed, it will delete all record!";
$add_record = "Add";
$table = "Table";
$search = "Search";
$by = "By";
$continue = "Continue";
$first = "<< First";
$previous = "< Previous";
$total = "Total";
$next = "Next >";
$last = "Last >>";
$show_all = "Show All";
$delete_confirm	= "Are you sure you want to delete this record?";
$add_search = "Add Search Object";
$export = "Export";
?>
