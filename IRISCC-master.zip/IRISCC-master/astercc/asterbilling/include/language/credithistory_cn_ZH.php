<?
$like = "包含";
$modifytime = "修改时间";
$clid = "分机";
$srccredit = "修改前余额";
$modifystatus = "修改状态";
$modifyamount = "修改金额";
$resellername = "代理商";
$group  = "分组";
$modifyby = "修改人";
?>
