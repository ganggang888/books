<?
$user_title="Nombre de Usuario ";
$manager_title="Administracion ";

$username="Nombre de Usuario ";
$password="Contraseña ";
$submit="Enviar ";
$please_waiting = 'Accediendo, Por favor espere';
$username_cannot_be_blank = "Nombre de usuario no puede estar en blanco ";
$password_cannot_be_blank = "Contraseña no puede estar en blanco ";
$login_success = "Acceso de Usuario exitoso";
$login_failed = "Acceso Fallido, Por favor cheque su login y password";
$ami_connect_failed = "Coinexion a AMI fallo, Alguna funcion podría no funcionar, por favor revise su archivo de configuracion";
$extension_not_online = "Extension esta desconectada, por favor revise su dispositivo";
$server_connection_test		= "Prueba de conexion al servidor: ";
$pass				= "Paso";
$device_status			= "Estado del dispositivo";
$continue			= "Continuar";
$no_pass			= "No paso, Por favor revise su archivo de configuracion";
$invalid_string		= "Entrada Invalida, Solo digitos y letras son permitidas";
?>
