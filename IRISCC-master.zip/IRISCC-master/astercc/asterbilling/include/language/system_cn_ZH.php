<?
//En for mangaer
$reload_info = "- 立即重载asterisk (不会影响当前的通话)";
$restart_info = "- 立即重新启动asterisk (所有当前通话将会被挂断)";
$reboot_info = "- 重新启动astercc BOX 服务器 (所有当前通话将会被挂断)";
$shutdown_info = "- 关闭astercc BOX 服务器 (所有当前通话将会被挂断)";
$restart_asterrc_daemon = "重启 asterrc 计费进程";
$system = "系统管理";
$reload_asterisk = "重载 asterisk";
$restart_asterisk = "重启 asterisk";
$restart_asterrc = "重启 asterrc";
$reboot_asterccbox = "重启 astercc BOX";
$shutdown_asterccbox = "关闭 astercc BOX";
$are_you_sure_to = "您确定要";
$asterisk_have_been_reloaded = "重载asterisk完毕";
$asterisk_have_been_restart = "重启asterisk完毕";
$server_is_rebooting = "服务器正在重启";
$server_is_shuting_down = "服务器正在关机";
$current_channels = "当前系统通道";
$refresh=' 刷新 ';
$hangup='挂 断';
?>