<?
$calldate = "Datum";
$src = "Ursprung";
$dst = "Ziel";
$duration = "Dauer";
$billsec = "Verrechnete Dauer";
$disposition = "Status";
$credit = "Kosten";
$destination = "Land";
$memo = "Anmerkung";
$like = "Wie";

?>
