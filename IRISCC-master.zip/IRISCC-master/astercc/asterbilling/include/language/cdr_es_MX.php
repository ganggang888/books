<?
$calldate = "Fecha llamada";
$src = "Origen";
$dst = "Destino";
$duration = "Duracion";
$billsec = "Segundos facturados";
$disposition = "Estado";
$credit = "Credito";
$destination = "Tipo Destino";
$memo = "Nota";
$like = "Como";

?>
