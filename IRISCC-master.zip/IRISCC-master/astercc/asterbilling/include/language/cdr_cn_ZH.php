<?
$calldate = "呼叫时间";
$src = "主叫";
$dst = "被叫";
$duration = "通话时长";
$billsec = "计费时长";
$disposition = "状态";
$credit = "费用";
$destination = "目标";
$memo = "备注";
$like = "包含";
$customer_id = "客户ID";
$discount = "折扣";
$are_you_sure_to_archive_cdr_early_than = "确定要存档早于";
$months = "个月的CDR数据";
$no_cdr_data_early_than = "没有早于";
$archive_success = "存档成功";
$file_save_in = "存档文件为";
$clear_cdr_date_success = "清除CDR数据成功";
$cant_create_archive_directory = "创建存档目录失败";
$cant_create_archive_file = "创建存档文件失败";
?>
