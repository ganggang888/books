<?
$title="Ouverture de session ";
$username="Nom d'utilisateur ";
$password="Mot de passe ";
$submit="Envoyer ";
$please_waiting = 'Login, veuillez patienter ';
$username_cannot_be_blank = "Le nom d'utilisateur ne peut pas �tre vide";
$password_cannot_be_blank = "Le mot de passe ne peut pas �tre vide";
$login_success = "Connexion effectuee avec succ�s";
$login_failed = "Connexion ratee, veuillez verifier votre nom d'utilisateur / mot de passe";
$ami_connect_failed = "AMI connexion erreur, certaines fonction ne fonctionne pas, verifiez vos fichiers de configuration";
$extension_not_online = "extension is off line, please check your device";
$server_connection_test		= "Test de connexion au serveur: ";
$pass				= "passe";
$device_status			= "etat du peripherique";
$continue			= "Continuer";
$no_pass			= "erreur, veuillez verifier vos fichiers de configuration";
$invalid_string		= "Erreur, n'inserez que des chiffres";
?>
