<?
//Cn for account manager
$add_account = "添加了一个新帐号";
$update_rec = "该记录已更新";
$rec_cannot_update = "该记录不能被更新";
$rec_cannot_insert = "无法添加记录";
$delete_rec = "记录被删除";
$rec_cannot_delete = "该记录不能被删除";
$username = "用户名 ";
$password = "密码 ";
$extension = "分机号码 ";
$extensions = "可观察的分机";
$extensions_note = "分机之间用逗号隔开 ";
$continue = "继续";
$obligatory_fields = "带*的为必填项目";
$adding_account = "添加用户";
$edit_account = "编辑用户";
$usertype = "用户类型";
$usertype_note = "只能使用 admin 或 callshop";
$channel	= "通道";	// added 2007/10/30 by solo
$account_detail		= "账户信息";	// added 2007/10/30 by solo
$account_code		= "账户标识";	// added 2007/11/12 by solo
$username_repeat = "用户名重复";
$like = "包含";
$reseller = "代理商";
$group = "组";
$group_admin = "组管理员";
$admin = "系统管理员";
$operator = "操作员";
$action = "动作";
$status = "属性";
$failed_cause = "失败原因";
$cretime = "创建时间";
$option = "操作";
$local = "本地";
?>
