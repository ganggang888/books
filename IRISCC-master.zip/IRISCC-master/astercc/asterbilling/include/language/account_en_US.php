<?
//En for mangaer
$add_account = "New account record added";
$update_rec = "A record has been updated";
$rec_cannot_update = "The record could not be updated";
$rec_cannot_insert = "The record could not be inserted";
$delete_rec = "Record Deleted";
$rec_cannot_delete = "The record could not be deleted";
$username = "User Name ";
$password = "Password ";
$extension = "Extension ";
$extensions = "Extensions";
$extensions_note = "use comma between extensions ";
$continue = "Continue";
$obligatory_fields = "* Obligatory fields";
$adding_account = "Adding Account";
$edit_account = "Edit Account";
$usertype = "User Type";
$usertype_note = "support admin,callshop";
$channel	= "Channel";	// added 2007/10/30 by solo
$account_detail		= "Account Detail";	// added 2007/10/30 by solo
$account_code		= "Account Code";	// added 2007/11/12 by solo
$username_repeat = "user name repeat";
$local = "Local";
?>