<?
$like = "Como ";
$modifytime = "Modificar tempo";
$clid = "Cabine";
$srccredit = "Crédito origem";
$modifystatus = "Modificar Status";
$modifyamount = "Modificar Quantidade";
$resellername = "Distribuidor";
$group  = "Callshop";
$modifyby = "Modificar por";
?>
