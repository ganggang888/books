<?
$title="帐户登入 ";
$user_title="用户登入";
$manager_title="管理员登入";
$username="帐户 ";
$password="密码 ";
$submit="提交 ";
$please_waiting="正在验证, 请稍侯 ";
$username_cannot_be_blank = "请输入账户名称";
$password_cannot_be_blank = "请输入账户密码";
$login_success = "用户登入成功";
$login_failed = "登入失败,请检查用户名密码";
$asterisk_connect_failed = "AMI连接失败,部分呼叫控制功能无法使用,请检查配置文件";
$extension_not_online = "分机不在线, 请检查您的分机配置";
$server_connection_test		= "服务器连接测试: ";
$pass				= "通过";
$device_status			= "设备状态";
$continue			= "继续";
$no_pass			= "失败, 请检查服务器配置文件";
$invalid_string		= "输入数据中含有非法字符，仅允许字符或者数字";
$valid_code		= "验证码";
$remember_me	= "记住我";
$page_style = "风格";
$classic = "经典版";
$simple = "简化版";
$language = "语言";
$please_install_php_pear = "请先安装php-pear";
?>