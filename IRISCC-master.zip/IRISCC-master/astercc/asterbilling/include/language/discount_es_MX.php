<?
$discount	= "Descuento";
$amount = "Cantidad";
$create_time = "Tiempo de Creacion";
$like = "Como";
$edit_discount = "Editar Cuenta";
$add_discount = "Agregar Descuento";
$continue = "Continuar";
$discount_must_be_ge_0_and_le_1 = "Descuento debe estar entre 1 y 0";
$amount_duplicate = "Cantidad Duplicada";
$obligatory_fields = "Campos Obligatorios";
?>
