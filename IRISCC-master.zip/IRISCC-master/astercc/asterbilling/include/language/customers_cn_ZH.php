<?
$pin	= "密码";
$first_name = "名字";
$last_name = "姓氏";
$amount = "总计额度";
$create_time = "创建时间";
$like = "包含";
$discount = "折扣";
$edit_customer = "修改客户";
$add_customer = "添加客户";
$dynamic = "动态";
$static = "静态";
$continue = "继续";
$pin_field_cant_be_null = "客户密码不能为空";
$pin_duplicate = "客户密码重复";
$discount_must_be_ge_0_and_le_1 = "折扣数必须大于0小于1";
$obligatory_fields = "必填字段";
?>
