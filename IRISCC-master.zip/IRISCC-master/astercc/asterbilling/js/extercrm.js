function openwindow(url){
	window.open   (url,   'CRMWINDOW','height='+screen.availHeight+',   width='+screen.availWidth+',   top=0,   left=0,   toolbar=no,   menubar=no,   scrollbars=yes,   resizable=yes,   location=yes,   status=yes');
}
