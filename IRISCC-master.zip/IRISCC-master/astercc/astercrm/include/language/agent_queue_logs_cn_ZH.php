<?php
$action = "操作";
$queue = "队列";
$account = "账户";
$pausetime = "暂停时间";
$reasion = "暂停原因";
$cretime = "创建时间";
$like = "包含";
$all = "全部";
$agent_queue_statistics = "坐席队列统计";
?>