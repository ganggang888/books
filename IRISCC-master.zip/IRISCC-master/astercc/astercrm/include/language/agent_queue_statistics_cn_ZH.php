<?php
$agent_name = "坐席名";
$all = "全部";
$today = "今天";
$this_week = "本周";
$this_month = "本月";
$last_3_months = "上三个月";
$this_year = "今年";
$last_year = "去年";
$from = "从";
$to = "到";
$cal = "日期";
$list = "列表";
$text = "文本";
$username = "账户名";
$account = "账户";
$queue = "队列";
$pause_nums = "暂停次数";
$pause_time = "暂停时间";
?>