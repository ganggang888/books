<?php
$agent_name = "Agent Name";
$rate = "Rate";
$all = "All";
$today = "Today";
$this_week = "This Week";
$this_month = "This Month";
$last_3_months = "Last 3 Months";
$this_year = "This Year";
$last_year = "Last Year";
$from = "From";
$to = "To";
$cal = "Cal";
$list = "List";
$text = "Text";
$account = "Account";
$queue = "Queue";
$pause_nums = "Pause Nums";
$pause_time = "Pause Time";
?>