<?php
$action = "Action";
$queue = "Queue";
$account = "Account";
$pausetime = "Pause Time";
$reasion = "Reasion";
$cretime = "Cretime";
$like = "like";
$all = "ALL";
$agent_queue_statistics = "Agent Queue Statistics";
?>