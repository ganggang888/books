<?php
$add_account = "Ein neues Benutzerkonto wurde hinzugefügt";
$update_rec = "Eintrag wurde aktualisiert";
$rec_cannot_update = "Der Eintrag konnte nicht aktualisiert werden";
$rec_cannot_insert = "Ihr Eintrag konnte nicht hinzugefügt werden";
$delete_rec = "Eintrag gelöscht";
$rec_cannot_delete = "Der Eintrag kann nicht gelöscht werden";
$username = "Benutzer Name ";
$password = "Passwort ";
$extension = "Erweiterung";
$extensions = "Erweiterung";
$extensions_note	= "bitte benutzen Sie ein Komma zwischen den Erweiterungen";
$continue = "Weiter";
$obligatory_fields = "* Obligatorische Felder";
$adding_account = "Benutzerkonto hinzufügen";
$edit_account = "Zugang ändern";
$usertype = "Benutzer Type";
$usertype_note = " "; //Nutzung nur durch Admin
$channel	= "Channel";	// added 2007/10/30 by solo
$account_detail		= "Account Detail";	// added 2007/10/30 by solo
$account_code		= "Account Code";	// added 2007/11/12 by solo
$username_repeat = "user name repeat";
?>